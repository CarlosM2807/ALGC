import numpy as np

import seaborn as sb

import matplotlib.pyplot as plt

import math

import random

import time

#relleno la matriz con los valores adecuados
#Para las funciones 1 y 3 siempre alcanza el maximo absoluto, por lo tanto, aplicando el algoritmo MonteCarlo, todos los puntos llegan al max y la probabilidad es del 100%
#Sin embargo para la 2 y 4 que no siempre llega al maximo absoluto, tiene mas sentido, indica cuantos puntos de todos llegan al max absoluto e imprime la probabilidad de que llegue

def rellenaM(matriz,n,m):  
    for i in range(n):
        for j in range(m):
            x=0+j*(math.pi/(n-1))                                     #hallamos el valor de x
            y=(math.pi)-i*(math.pi/(m-1))                             #hallamos el valor de y

            #matriz[i][j]= math.sin(x)+ math.cos(y) + math.sin(x)*math.cos(y) + math.sin(2*x)       #FUNCION 1
            #matriz[i][j]= (2*math.sin(x)*math.cos(y/2)) + x + math.log(abs(y-math.pi/2))            #FUNCION 2
            #matriz[i][j]= math.sin(x)*math.cos(y) + math.sqrt(x*y)                                 #FUNCION 3
            matriz[i][j]= math.sin(x*7) + math.cos((y+math.pi/4)*4) + (x+y)                        #FUNCION 4

#comienza el algoritmo voraz 

def algoritmoHC(matriz,n,m,prob,arrayPinta):
    
    x=random.randrange(0, n)                                     #selecciona un numero aleatorio entre 0 y n para la componente x del punto aleatorio
    y=random.randrange(0, m)                                     #selecciona un numero aleatorio entre 0 y n para la componente y del punto aleatorio                                   

    encontradoMax = False                                        #creo un boolean que indica si se ha encontrado el valor maximo o no 

    #comparamos el valor de la casilla random, con el de las casillas colindantes y vamos seleccionando el mayor para llegar al valor maximo

    while(not encontradoMax):                                    #mientras no encuentre el maximo...
        valorPunto=matriz[x][y]                                  #asignamos como punto de partida del algoritmo el valor de la casilla x,y de la matriz
        valorCambio = valorPunto
        newX=x
        newY=y
        if((x+1)<n):                                             #comprueba que no se sale del rango al desplazarse a la derecha, es decir no es mayor que n
            if(matriz[x+1][y]>valorPunto):                       #si el valor de la posicion de la derecha del punto es mayor
                newX=x+1                                         #el valor de la x va a ser el de la derecha (x+1)
                newY=y                                           #y el valor de la y es el mismo puesto que no cambia
                valorPunto=matriz[x+1][y]                        #cambia el valor, y ahora este valor, es el de la nueva posicion la de la derecha del punto original
        
        if((y+1)<m):                                             #comprueba que no se sale del rango al desplazarse a abajo, es decir no es mayor que m
            if(matriz[x][y+1]>valorPunto):                       #si el valor de la posicion de abajo es mayor
                newX=x                                           #el valor de la x va a ser el mismo puesto que no cambia
                newY=y+1                                         #el valor de la y va a ser el de abajo (y+1)
                valorPunto=matriz[x][y+1]                        #cambia el valor, y ahora este valor es el de la nueva posicion, abajo del punto original

        if((x-1)>=0):                                            #comprueba que no se sale del rango al desplazarse a la izquierda, es decir no es menor que 0        
            if(matriz[x-1][y]>valorPunto):                       #si el valor de la posicion de la izquierda del punto es mayor
                newX=x-1                                         #el valor de la x va a ser el de la izquierda (x-1)
                newY=y                                           #el valor de la y va a ser el mismo puesto que no cambia
                valorPunto=matriz[x-1][y]                        #cambia el valor, y ahora este valor es el de la nueva posicion de la izquierda del punto original
        
        if((y-1)>=0):                                            #comprueba que no se sale del rango al desplazarte hacia arriba, es decir no es menor que 0
            if(matriz[x][y-1]>valorPunto):                       #si el valor de la posicion de arriba es mayor
                newX=x                                           #el valor de la x va a ser el mismo puesto que no cambia
                newY=y-1                                         #el valor de la y va a ser el de arriba (y-1)
                valorPunto=matriz[x][y-1]                        #cambia el valor, y ahora este valor es de la nueva posicion, arriba del punto original
                                                                
                                                                #cambia valor quiere decir que se selecciona ese punto como referencia de esta forma se va actualizando
                                                                #el valor y siempre se va cogiendo el mayor                                
        if(valorCambio == valorPunto):
            encontradoMax = True                                 #encuentra el valor maximo y modifico el estado del booleano a TRUE
            #print("El maximo que alcanza es: ",valorCambio)     #indica a que valor maximo llega el punto

        if(valorCambio == np.max(matriz)):                        #si el maximo al que llega es el absoluto, incrementa en 1 el numero de puntos que llegan al max abs
            prob = prob + 1

        arrayPinta.append([x,y])                                 #introduce en un array, los valores de los puntos x e y, para pintar todos los caminos a la vez
        x=newX
        y=newY
    return prob                                                  #retorna el numero de puntos que llegan al maximo absoluto

#recorre la matriz y halla el valor maximo

def maxRecorriendoM(matriz,n,m):
    max_value = np.min(matriz)                                   #asigno al valor maximo, el valor minimo para que se vaya actualizando a medida que recorre la matriz
    for i in range(n):                                           #recorro la matriz entera
        for j in range(m):
            if (max_value < matriz[i][j]):                       #si el valor maximo es menor que el valor de la casilla que se encuentra 
                max_value = matriz[i][j]                         #actualiza el valor maximo dandole el valor de la casilla
    return max_value



def pintaCaminos(arrayPinta,matriz):                            #almacena en un array todas las casillas para luego pintarlas
    for i in range(len(arrayPinta)):                            #recorre la matriz de casillas por donde pasa el camino
        matriz[arrayPinta[i][0]][arrayPinta[i][1]] = np.min(matriz) #coge la casilla del array y la pinta (asignando valor minimo)


#pedimos los valores para crear la matriz n*m

n = int(input("Introduce el numero de filas: "))
m = int(input("Introduce el numero de columnas: "))
p = int(input("Introduce el numero de 'paracaidistas' a soltar: "))   #solicitamos el numero de puntos 

matriz = np.zeros((n,m))                                     #relleno la matriz de ceros

tRellenaIncial = time.time()
rellenaM(matriz,n,m)                                         #invoco al metodo que me rellena la matriz
tRellenaFinal = time.time()
tRellenaIncial = tRellenaFinal - tRellenaIncial              #contiene el tiempo que tarda en generar la matriz

print("El tiempo que tarda en rellenar la matriz es: ",tRellenaIncial," segundos")

###############
# MONTE CARLO #
###############

prob = 0                                                     #numero de puntos que llegan al maximo   
arrayPinta = []                                              #inicializo el array que va a contener las coordenadas para pintar los caminos

tiempoInicio = time.time()                                   #inicializo una variable time para calcular el tiempo que tarda el algoritmo voraz en encontrar el maximo

for l in range (p):                                         #lo haga tantas veces como puntos randoms se solicitan, MonteCarlo
    prob = algoritmoHC(matriz,n,m,prob,arrayPinta)          #invoco al metodo encargado de hacer el algortimo HillClimb

tiempoFinal = time.time()                                    #esta variable contiene el tiempo justo despues de hacer el algoritmo
tiempoInicio = tiempoFinal - tiempoInicio                    #resto el tiempo final menos el inicial y asi hallo cuanto tiempo ha tardado

print("El numero de 'paracaidistas' que encuentran el maximo absoluto es: ",prob)       #imprime el numero de puntos que llegan al maximo absoluto
print("El porcentaje de encontrar el valor maximo correcto es: ", (prob/p)*100," %")    #imprime el % de los que llegan, de todos los soltados

######################
# RECORRIENDO MATRIZ #
######################

tRecorrerInicio = time.time()                                  #inicializo una variable time para calcular el tiempo que tarda en hallar el maximo    

maximoR = maxRecorriendoM(matriz,n,m)                                    #invoco al metodo que halla el valor maximo recorriendo la matriz entera

tRecorrerFinal = time.time()                             #de la misma forma que antes, la variablee contiene el tiempo justo despues de recorrer la matriz y hallar el maximo
tRecorrerInicio = tRecorrerFinal - tRecorrerInicio           #resto el tiempo final menos el inicial para hallar el tiempo que ha tardado
print("El maximo recorriendo la matriz es: ",maximoR)

##############
# RESULTADOS #
##############

print("#-#-#-#-#-#-#-#-#-#-#-#-#")
print("# COMPARACIONES TIEMPOS #")
print("#-#-#-#-#-#-#-#-#-#-#-#-#")
print("El tiempo que tarda el algoritmo en encontrar el maximo es: ",tiempoInicio," segundos")    #imprimo el tiempo que tarda el algoritmo voraz
print("El tiempo que tarda encontrar el maximo absoluto recorriendo la matriz: ",tRecorrerInicio," segundos")

#################
# PINTO CAMINOS #
#################

pintaCaminos(arrayPinta,matriz)                              #pinta todos los caminos en el mapa

#########################
# MUESTRO MAPA DE CALOR #
#########################

heatmap = sb.heatmap(matriz, cmap='hot',cbar_kws={'label': 'Escala de colores'})       #crea el heatmap con los valores de la matriz y cmap, lo que hace es modifica los colores  utilizados
                                                                                        #he usado hot puesto son los colores que mas se adaptan a la foto que hay en Moddle
plt.ylabel("Valor de las X")                                 #eje de las x
plt.xlabel("Valor de las Y")                                 #eje de las y
plt.show()                                                   #muestra el heatmap


import numpy as np

import seaborn as sb

import matplotlib.pyplot as plt

import math

import random

import time

#relleno la matriz con los valores adecuados
#modifico el metodo para que me retorne la matriz, e igualarlo a matrizCambio en la linea 93, ya que si cada vez que se ejecutase el programa
#me tenia que generar la matrizCambio haciendo esto rellenaM(matrizCambio,n,m), el programa tardaba entorno a 20 veces mas de tiempo 

def rellenaM(matriz,n,m):  
    for i in range(n):
        for j in range(m):
            x=-1.5+j*(4/(n-1))                                     #hallamos el valor de x en el rango adecuado
            y=2.5-i*(4/(m-1))                                      #hallamos el valor de y en el rango adecuado
            matriz[i][j]=  math.cos((x*x+y*y)*12)/(2*((x*x+y*y)*3.14+1))  #Rellenamos la matriz con el valor determinado
    return matriz                                                  #retorno la matriz

#comienza el algoritmo voraz 

def algoritmoHC(matriz,n,m,contVcesMax,arrayPinta):
    x=random.randrange(0, n)                                     #selecciona un numero aleatorio entre 0 y n para la componente x del punto aleatorio
    y=random.randrange(0, m)                                     #selecciona un numero aleatorio entre 0 y n para la componente y del punto aleatorio                                   

    encontradoMax = False                                        #creo un boolean que indica si se ha encontrado el valor maximo o no 

    #comparamos el valor de la casilla random, con el de las casillas colindantes y vamos seleccionando el mayor para llegar al valor maximo

    while(not encontradoMax):                                    #mientras no encuentre el maximo...
        valorPunto=matriz[x][y]                                  #asignamos como punto de partida del algoritmo el valor de la casilla x,y de la matriz
        valorCambio = valorPunto
        newX=x
        newY=y
        if((x+1)<n):                                             #comprueba que no se sale del rango al desplazarse a la derecha, es decir no es mayor que n
            if(matriz[x+1][y]>valorPunto):                       #si el valor de la posicion de la derecha del punto es mayor
                newX=x+1                                         #el valor de la x va a ser el de la derecha (x+1)
                newY=y                                           #y el valor de la y es el mismo puesto que no cambia
                valorPunto=matriz[x+1][y]                        #cambia el valor, y ahora este valor, es el de la nueva posicion la de la derecha del punto original
        
        if((y+1)<m):                                             #comprueba que no se sale del rango al desplazarse a abajo, es decir no es mayor que m
            if(matriz[x][y+1]>valorPunto):                       #si el valor de la posicion de abajo es mayor
                newX=x                                           #el valor de la x va a ser el mismo puesto que no cambia
                newY=y+1                                         #el valor de la y va a ser el de abajo (y+1)
                valorPunto=matriz[x][y+1]                        #cambia el valor, y ahora este valor es el de la nueva posicion, abajo del punto original

        if((x-1)>=0):                                            #comprueba que no se sale del rango al desplazarse a la izquierda, es decir no es menor que 0        
            if(matriz[x-1][y]>valorPunto):                       #si el valor de la posicion de la izquierda del punto es mayor
                newX=x-1                                         #el valor de la x va a ser el de la izquierda (x-1)
                newY=y                                           #el valor de la y va a ser el mismo puesto que no cambia
                valorPunto=matriz[x-1][y]                        #cambia el valor, y ahora este valor es el de la nueva posicion de la izquierda del punto original
        
        if((y-1)>=0):                                            #comprueba que no se sale del rango al desplazarte hacia arriba, es decir no es menor que 0
            if(matriz[x][y-1]>valorPunto):                       #si el valor de la posicion de arriba es mayor
                newX=x                                           #el valor de la x va a ser el mismo puesto que no cambia
                newY=y-1                                         #el valor de la y va a ser el de arriba (y-1)
                valorPunto=matriz[x][y-1]                        #cambia el valor, y ahora este valor es de la nueva posicion, arriba del punto original
                                                                
                                                                #cambia valor quiere decir que se selecciona ese punto como referencia de esta forma se va actualizando
                                                                #el valor y siempre se va cogiendo el mayor                                              
        if(valorCambio == valorPunto):
            encontradoMax = True                                 #encuentra el valor maximo y modifico el estado del booleano a TRUE

        arrayPinta.append([x,y])                                  #introduce el valor de la casilla que sigue el algoritmo, para pintarlo    
        x=newX
        y=newY

    if(valorPunto == np.max(matriz)):                             #si encuentra el maximo , suma uno a la variable contador, de esta forma  va a contener
        contVcesMax= contVcesMax + 1                                            #de las veces que se lanzael punto, si una de esas llega al maximo absoluto 

    return contVcesMax

def pintaCaminos(arrayPinta,matriz):                            #almacena en un array todas las casillas para luego pintarlas
    for i in range(len(arrayPinta)):                            #recorre la matriz de casillas por donde pasa el camino
        matriz[arrayPinta[i][0]][arrayPinta[i][1]] = np.min(matriz) #coge la casilla del array y la pinta (asignando valor minimo)


#pedimos los valores para crear la matriz n*m

n = int(input("Introduce el numero de filas: "))
m = int(input("Introduce el numero de columnas: "))
p = int(input("Introduce el numero de paracaidistas: "))                              #el numero de paracaidistas, que suelta cada vez
veces = int(input("Introduce el numero de veces que se suelta el paracaidista: "))    #solicita la veces que se repite el programa

matriz = np.zeros((n,m))                                              #relleno la matriz de ceros

tRellenaIncial = time.time()
matriz = rellenaM(matriz,n,m)                                         #invoco al metodo que me rellena la matriz
tRellenaFinal = time.time()
tRellenaIncial = tRellenaFinal - tRellenaIncial                      #contiene el tiempo que tarda en rellenar la matriz

matrizCambio = []                                                    #creo una matriz "auxiliar", que va a servir para asignale la matriz original

print("El tiempo que tarda en rellenar la matriz es: ",tRellenaIncial," segundos")  #printea el tiempo en rellenar la matriz

###################
# ALGORITMO VORAZ #
###################

prob = 0                                                     #contiene el numero de veces que llega al menos una vez al maximo
arrayPinta = []                                              #inicializo el array que va a contener las coordenadas para pintar los caminos

tiempoInicio = time.time()                                   #inicializo una variable time para calcular el tiempo que tarda el algoritmo voraz en encontrar el maximo

for v in range(veces):                                       #lo repite el numero de veces que introduce el usuario
    matrizCambio = matriz
    contador = 0                                             #reiniciamos el valor del contador

    for g in range(p):                                       #lanza tantos paracaidistas como introduce el usuario
        contador = algoritmoHC(matriz,n,m,contador,arrayPinta)          #contiene si llega al maximo aunque sea una vez o no, si vale 1 llega, si vale 0 no

    if(contador > 0):                                        #si al menos llega una vez, suma uno a la probabilidad, para ver cuantas veces se llega al maximo y cuantas no
        prob = prob +1


tiempoFinal = time.time()                                    #esta variable contiene el tiempo justo despues de hacer el algoritmo
tiempoInicio = tiempoFinal - tiempoInicio                    #resto el tiempo final menos el inicial y asi hallo cuanto tiempo ha tardado

print("El tiempo que tarda el algoritmo es: ",tiempoInicio," segundos")    #imprimo el tiempo que tarda el algoritmo voraz
print("El % de veces que alcanza el maximo al menos una vez es: ", (prob/veces)*100, " %")              #el porcentaje que llega al maximo





#                                                                       PARTE GRAFICA                      

#################
# PINTO CAMINOS #
#################

#pintaCaminos(arrayPinta,matriz)                              #pinta todos los caminos en el mapa

#########################
# MUESTRO MAPA DE CALOR #
#########################

#heat_map = sb.heatmap(matriz, cmap='hot',cbar_kws={'label': 'Escala de colores'})                    #crea el heatmap con los valores de la matriz y cmap, lo que hace es modifica los colores  utilizados
                                                                                                    #he usado hot puesto son los colores que mas se adaptan a la foto que hay en Moddle
#plt.ylabel("Valor de las X")
#plt.xlabel("Valor de las Y")
#plt.show()        